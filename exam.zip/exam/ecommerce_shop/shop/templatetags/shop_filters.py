from django import template

register = template.Library()

@register.filter
def get_status_color(status):
    colors = {
        'new': 'yellow',
        'confirmed': 'blue',
        'shipped': 'green',
        'delivered': 'darkgreen',
        'cancelled': 'red',
    }
    return colors.get(status, 'gray')
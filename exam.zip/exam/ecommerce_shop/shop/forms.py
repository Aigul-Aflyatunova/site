from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.core.exceptions import ValidationError
from .models import User, Order, Review, Product
import re


class RegisterForm(UserCreationForm):
    username = forms.CharField(
        label='Логин',
        min_length=6,
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Введите логин (мин. 6 символов)'})
    )
    full_name = forms.CharField(
        label='ФИО',
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Введите ФИО'})
    )
    phone = forms.CharField(
        label='Телефон',
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': '8(XXX)XXX-XX-XX'})
    )
    email = forms.EmailField(
        label='Электронная почта',
        widget=forms.EmailInput(attrs={'class': 'form-input', 'placeholder': 'example@mail.ru'})
    )
    password1 = forms.CharField(
        label='Пароль',
        min_length=8,
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': 'Введите пароль (мин. 8 символов)'})
    )
    password2 = forms.CharField(
        label='Подтверждение пароля',
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': 'Повторите пароль'})
    )

    class Meta:
        model = User
        fields = ('username', 'full_name', 'phone', 'email', 'password1', 'password2')

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not re.match(r'^[A-Za-z0-9]+$', username):
            raise ValidationError('Логин должен содержать только латиницу и цифры')
        return username

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if not re.match(r'^8\(\d{3}\)\d{3}-\d{2}-\d{2}$', phone):
            raise ValidationError('Телефон должен быть в формате: 8(ХХХ)ХХХ-ХХ-ХХ')
        return phone

    def clean_full_name(self):
        full_name = self.cleaned_data.get('full_name')
        if not re.match(r'^[А-Яа-я\s]+$', full_name):
            raise ValidationError('ФИО должно содержать только кириллицу и пробелы')
        return full_name


class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(
        label='Логин',
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Введите логин'})
    )
    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': 'Введите пароль'})
    )


class OrderForm(forms.ModelForm):
    product = forms.ModelChoiceField(
        queryset=Product.objects.all(),
        label='Товар',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    quantity = forms.IntegerField(
        label='Количество',
        min_value=1,
        widget=forms.NumberInput(attrs={'class': 'form-input', 'placeholder': 'Введите количество'})
    )
    payment_method = forms.ChoiceField(
        choices=Order.PAYMENT_CHOICES,
        label='Способ оплаты',
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = Order
        fields = ('product', 'quantity', 'payment_method')


class ReviewForm(forms.ModelForm):
    rating = forms.ChoiceField(
        choices=[(i, f'{i} ★') for i in range(1, 6)],
        label='Оценка',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    comment = forms.CharField(
        label='Отзыв',
        widget=forms.Textarea(attrs={'class': 'form-textarea', 'rows': 4, 'placeholder': 'Напишите ваш отзыв...'})
    )

    class Meta:
        model = Review
        fields = ('rating', 'comment')
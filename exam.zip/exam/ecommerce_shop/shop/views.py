from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from .models import User, Order, Product, Review
from .forms import RegisterForm, CustomLoginForm, OrderForm, ReviewForm


def register_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password1'])
            user.save()
            login(request, user)
            messages.success(request, 'Регистрация прошла успешно!')
            return redirect('index')
    else:
        form = RegisterForm()

    return render(request, 'shop/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {user.username}!')
                return redirect('index')
        else:
            messages.error(request, 'Неверный логин или пароль')
    else:
        form = CustomLoginForm()

    return render(request, 'shop/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.info(request, 'Вы вышли из системы')
    return redirect('login')


@login_required
def index_view(request):
    products = Product.objects.all()
    return render(request, 'shop/index.html', {'products': products})


@login_required
def orders_view(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'shop/orders.html', {'orders': orders})


@login_required
def create_order_view(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.user = request.user
            order.status = 'new'
            order.save()
            messages.success(request, 'Заказ успешно создан и отправлен на рассмотрение администратору!')
            return redirect('orders')
    else:
        form = OrderForm()

    return render(request, 'shop/create_order.html', {'form': form})


@login_required
def add_review_view(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)

    if order.status != 'delivered':
        messages.error(request, 'Отзыв можно оставить только после получения заказа')
        return redirect('orders')

    if hasattr(order, 'review'):
        messages.error(request, 'Вы уже оставили отзыв на этот заказ')
        return redirect('orders')

    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.order = order
            review.user = request.user
            review.product = order.product
            review.save()
            messages.success(request, 'Спасибо за ваш отзыв!')
            return redirect('orders')
    else:
        form = ReviewForm()

    return render(request, 'shop/add_review.html', {'form': form, 'order': order})


def admin_panel_view(request):
    if not request.user.is_authenticated:
        return redirect('login')

    if not request.user.is_staff:
        messages.error(request, 'У вас нет доступа к панели администратора')
        return redirect('index')

    status_filter = request.GET.get('status', '')
    search_query = request.GET.get('search', '')

    orders = Order.objects.all().order_by('-created_at')

    if status_filter:
        orders = orders.filter(status=status_filter)

    if search_query:
        orders = orders.filter(
            Q(user__username__icontains=search_query) |
            Q(product__name__icontains=search_query) |
            Q(id__icontains=search_query)
        )

    return render(request, 'shop/admin_panel.html', {
        'orders': orders,
        'status_filter': status_filter,
        'search_query': search_query,
        'status_choices': Order.STATUS_CHOICES
    })


@login_required
def update_order_status_view(request, order_id):
    if not request.user.is_staff:
        return JsonResponse({'error': 'Доступ запрещен'}, status=403)

    if request.method == 'POST':
        order = get_object_or_404(Order, id=order_id)
        new_status = request.POST.get('status')

        if new_status in dict(Order.STATUS_CHOICES):
            order.status = new_status
            order.save()
            messages.success(request, f'Статус заказа #{order.id} обновлен')
            return redirect('admin_panel')

    return redirect('admin_panel')


def get_products_api(request):
    products = list(Product.objects.values('id', 'name', 'price'))
    return JsonResponse(products, safe=False)

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index_view, name='index'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('orders/', views.orders_view, name='orders'),
    path('create-order/', views.create_order_view, name='create_order'),
    path('add-review/<int:order_id>/', views.add_review_view, name='add_review'),
    path('admin-panel/', views.admin_panel_view, name='admin_panel'),
    path('update-order-status/<int:order_id>/', views.update_order_status_view, name='update_order_status'),
    path('api/products/', views.get_products_api, name='api_products'),
]